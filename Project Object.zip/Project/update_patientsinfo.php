<?php
    include_once "Userfnc.php";
    include_once "updateform_patients.html";
    


    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $name = $_POST['Name'];
        $phone= $_POST['phone'];
        $national_id= $_POST['national_id'];
        $disease= $_POST['disease'];
        $filename=  "patients_list.txt";

        Updatepatient($name, $phone,$national_id,$disease,$filename);
    
        
    }
?>