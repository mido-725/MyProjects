<?php
include_once "Userfnc.php";
include_once "ReadEquipment.html";





if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $id= $_POST['ID'];
    
    
    
    $filename="ListofEquipment.txt";
    $arrayresult= getUserById($id,$filename);
    //$arrayresult[2]=Decrypt($arrayresult[2],3);
    echo "Equipment Information :" .$arrayresult[0] . " ~ " . $arrayresult[1] ;
}
?>