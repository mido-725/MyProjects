<?php
    include_once "medical_specialtyfnc.php";
    include_once "updateform_medicalspecialty.html";
    

    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $oid=$_POST['number'];;
        $id = $_POST['number_of_specialty'];
        $name = $_POST['name_of_specialty'];
        $filename=  "medical_specialty.txt";
        
        
        UpdateUser($oid,$id,$name,$filename);
    
        
    }
?>