<?php
include_once "Userfnc.php";
include_once "CreateEquipment.html";



if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $name = $_POST['Name'];
    
    $filename="ListofEquipment.txt";
    
    addEquipment($name,$filename);

    
}
?>