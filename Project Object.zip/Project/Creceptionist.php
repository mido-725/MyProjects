<?php
include_once "Iread";
include_once "Icreate";
    class Receptionist implements Iread , Icreate
    {
        function ReadInfo ()
        {

        }
        function AddInfo ()
        {
            
        }

    }
?>