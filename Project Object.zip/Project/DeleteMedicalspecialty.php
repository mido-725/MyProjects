<?php
    include_once "userfnc.php";
   // include_once "medical_specialtyfnc.php";
    include_once "DeleteForm_medicalspecialty.html";
    
    //$fileName="team.txt";
    
    $id;
    $filename;
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $id= $_POST['id'];
        $filename= "medical_specialty.txt";
        echo $id;
        
        DeleteUser($id,$filename);
    
        
    }
?>