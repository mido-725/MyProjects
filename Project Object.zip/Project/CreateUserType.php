<?php
include_once "Userfnc.php";
include_once "CreateUserType.html";



if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $name = $_POST['Name'];
    $filename="ListofUsersType.txt";
    
    addUserType($name,$filename);

    
}
?>