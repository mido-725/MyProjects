<?php
    include_once "Userfnc.php";
    include_once "ReadForm_patientsinfo.html";
    include_once "Functins.php";
    
    //$fileName="team.txt";
    
    $name;
    $filename;
    
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $name= $_POST['name'];
        $filename="patients_list.txt";
        $arrayresult= getpatientByname($name,$filename);
        echo "patient Information :" .$arrayresult[0] . " ~ " . $arrayresult[1] . " ~ " . $arrayresult[2] . " ~ ".$arrayresult[3] ;
        
    }
?>