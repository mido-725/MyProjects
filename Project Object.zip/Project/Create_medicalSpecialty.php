<?php
    include_once "Medical_specialtyFnc.php";
    include_once "CreateForm_MedicalSpecialty.html";
    
    //$fileName="team.txt";
    
    $nameOfSpecialty;
    $filename;
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $nameOfSpecialty = $_POST['NameOfspecialty'];;
        $filename= "medical_specialty.txt";
        
        addspeciality($nameOfSpecialty,$filename);
    
        
    }
?>