<?php
    include_once "Userfnc.php";
    include_once "DeleteForm_medicine.html";
    
    //$fileName="team.txt";
    
    $name;
    $filename;
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $name= $_POST['name'];
        $filename= "medicinelist.txt";
        echo $name;
        
        Deletemedicine($name,$filename);
    
        
    }
?>