<?php
include_once "Userfnc.php";
include_once "UpdateUserType.html";



if($_SERVER["REQUEST_METHOD"] == "POST") {
    

    // collect value of input field

    $Name= $_POST['Name'];
    $id= $_POST['ID'];

    $filename= "ListofUsersType.txt";

    
    UpdateEquipment($id,$Name,$filename);

    
}
?>