<?php
include_once "Userfnc.php";
include_once "ReadAppointment.html";





if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $id= $_POST['ID'];
    

    
    $filename="ListofAppointment.txt";
    $arrayresult= getUserById($id,$filename);
    //$arrayresult[2]=Decrypt($arrayresult[2],3);
    echo "User Information :" .$arrayresult[0] . " ~ " . $arrayresult[1] . " ~ " . $arrayresult[2] . " ~ ".$arrayresult[3]." ~ ".$arrayresult[4] ;
    
}
?>