<?php
include_once "medicineFnc.php";
include_once "CreateForm_medicine.html";

//$fileName="team.txt";

$name;
$quantity;
$expiration_date;

$filename;
if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $name = $_POST['Name'];
    $quantity= $_POST['quantity'];
    $expiration_date= $_POST['expiration_date'];
    $filename= "medicinelist.txt";
    echo $name;
    echo '~';
    echo $quantity;
    echo '~';
    echo $expiration_date;
    addmedicine($name,$quantity,$expiration_date,$filename);

    
}
?>