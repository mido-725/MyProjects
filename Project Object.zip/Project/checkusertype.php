<?php
function UserType($password, $RoleID)
{
    $fileName="UsersFile.txt";
    if (searchUser($fileName, $password."~".$RoleID)) {
        return true;
    } else {
        return false;
    }
}

?>