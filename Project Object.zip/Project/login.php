<?php

include_once "Userfnc.php";
include_once "Functins.php";
include_once "checkusertype.php";
include_once "login.html";

$email;
$password;

if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    
    $password= $_POST['Password'];
    
    $email= $_POST['Email'];

    $password=Encrypt($password,3);
    
    if(Login($email,$password)==true)
    {
        
        
        $UserType="manager";
        if(UserType($password,$UserType)==true)
        {
            header("location:managerchosefile.html");
        }
        $UserType="pharmacist";
        if(UserType($password,$UserType)==true)
        {
            header("location:PharmacistChoseFile.html");
        }
        $UserType="recptionist";
        if(UserType($password,$UserType)==true)
        {
            header("location:RecptionistChoseFile.html");
        }
    }
    else
    {
        echo 'Not correct Email Or Password';
    }
}

?>