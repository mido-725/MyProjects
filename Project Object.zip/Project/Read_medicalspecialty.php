<?php
    include_once "medical_specialtyfnc.php";
    include_once "ReadForm_medicalspecialty.html";
    include_once "Functins.php";
    
    //$fileName="team.txt";
    
    $id;
    $filename;
    
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $id= $_POST['numberofspecialty'];

        $filename="medical_specialty.txt";
        $arrayresult= getspecialtyByid($id,$filename);
        echo "specialty Information :" .$arrayresult[0] . " ~ " . $arrayresult[1];
        
    }
?>