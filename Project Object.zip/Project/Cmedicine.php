<?php
    class medicine 
    {
        private $id;
    
	function getId() {
		return $this->id;
	}
	
	
	function setId($id): self {
		$this->id = $id;
		return $this;
	}
}
?>