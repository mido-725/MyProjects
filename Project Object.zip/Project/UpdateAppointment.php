<?php
include_once "Userfnc.php";
include_once "UpdateAppointment.html";



if($_SERVER["REQUEST_METHOD"] == "POST") {
    

    // collect value of input field
    $Date = $_POST['Date'];
    $id= $_POST['ID'];
    $Time= $_POST['Time'];
    $Name= $_POST['Name'];
    $Specialty= $_POST['Specialty'];
    

    $filename= "ListofAppointment.txt";

    
    UpdateUser($id, $Time,$Name,$Specialty,$Date,$filename);

    
}
?>