<?php
include_once "Userfnc.php";
include_once "DeleteUserType.html";


if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $id= $_POST['ID'];
    
    
    $filename="ListofUsersType.txt";
    DeleteUser($id,$filename);

    
}
?>