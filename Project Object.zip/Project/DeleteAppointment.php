<?php
include_once "Userfnc.php";
include_once "DeleteAppointment.html";


if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $id= $_POST['ID'];
    
    $filename="ListofAppointment.txt";
    DeleteUser($id,$filename);

    
}
?>