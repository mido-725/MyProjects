<?php
include_once "Iread";
include_once "Icreate";
    class Pharmacist implements Iread , Icreate
    {
        function ReadInfo ()
        {

        }
        function AddInfo ()
        {
            
        }

   
	
}
?>