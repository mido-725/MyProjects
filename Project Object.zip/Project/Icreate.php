<?php
    interface Icreate
    {
        public function AddInfo ();
          
       
      
    }
?>