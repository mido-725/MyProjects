<?php
include_once "Functins.php";
//$fileName = "team.txt";

class userFunc 
{
// CREATE
function addUser($Email, $Password,$RoleID , $FullName,$fileName)
{
    $id = getLastId($fileName, "~") + 1;
    $record = $id . "~" . $Email . "~" . $Password . "~" . $RoleID . "~" .$FullName ;
	//echo $record;
    if (searchUser($fileName, $Email) == false) {
        StoreRecord($fileName, $record);
        return true;
    } else {
        return false;
    }

}

function addAppointment($Name,$Specialty,$Time,$Date,$fileName)
{
    $id = getLastId($fileName, "~") + 1;
    $record = $id . "~" .$Time. "~" .$Name. "~" .$Specialty. "~" . $Date;
	//echo $record;
    if (searchBYwords($fileName, $Name."~".$Specialty) ==true) 
    {
        echo 'Sorry There is user with the smae information';
        return true;
    }
    else 
    {
        StoreRecord($fileName, $record);
        return false;
    }
}

function addEquipment($Name,$fileName)
{
    $id = getLastId($fileName, "~") + 1;
    $record = $id . "~" .$Name;
	//echo $record;
    if (searchBYwords($fileName, $Name) ==true) 
    {
        echo 'Sorry Information used before';
        return true;
    }
    else 
    {
        StoreRecord($fileName, $record);
        return false;
    }
}

function addUserType($Name,$fileName)
{
    $id = getLastId($fileName, "~") + 1;
    $record = $id . "~" .$Name;
	//echo $record;
    if (searchBYwords($fileName, $Name) ==true) 
    {
        echo 'Sorry Information used before';
        return true;
    }
    else 
    {
        StoreRecord($fileName, $record);
        return false;
    }
}

// Read
function getUserById($Id,$fileName)
{
    
    $Record = getRowById($fileName, "~", $Id);

    $ArrayResult = explode("~", $Record);
    if (isset($ArrayResult[0])) 
    {
    $Result[0] = $ArrayResult[0];
    }
    if (isset($ArrayResult[1])) 
    {
    $Result[1] = $ArrayResult[1];
    }
    if (isset($ArrayResult[2])) 
    {
    $Result[2] = $ArrayResult[2];
    }
    if (isset($ArrayResult[3])) 
    {
    $Result[3] = $ArrayResult[3];
    }
    if (isset($ArrayResult[4])) 
    {
    $Result[4] = $ArrayResult[4];
    }
    return $Result;
}


function getAllUsers($fileName)
{
    
    $R = ListAll($fileName);
    return $R;
}

function getAllUsersByKeyWord($KeyWord,$fileName)
{
    
    $R = SearhKeyword($fileName, $KeyWord);
    //echo $R[0] ."Ayman";
    return $R;
}
function Login($Email, $Password)
{
    $fileName="UsersFile.txt";
    if (searchUser($fileName, $Email . "~" . $Password)) {
        return true;
    } else {
        return false;
    }
}


// Update
function UpdateUser($id, $Email, $Password, $RoleID, $FullName,$fileName)
{
    $record = $id . "~" . $Email . "~" . $Password . "~" . $RoleID  . "~" . $FullName. "\r\n";
    $r = getRowById($fileName, "~", $id);
    //echo $record ."NEW <br>";
    //echo $r ."NEW <br>";
    UpdateRecord($fileName, $record, $r);

}

function UpdateEquipment($id, $FullName,$fileName)
{
    $record = $id . "~" . $FullName."\r\n";
    $r = getRowById($fileName, "~", $id);

    UpdateRecord($fileName, $record, $r);

}


// Delete
function DeleteUser($id,$fileName)
{
    
    $r = getRowById($fileName, "~", $id);
    //echo $r;
    //exit();
    DeleteRecord($fileName, $r);
}

}

