<?php
    interface Iread
    {
        public function ReadInfo ();
          
       
      
    }
?>