<?php
include_once "Userfnc.php";
include_once "CreateForm.html";



if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $name = $_POST['Name'];
    $password= $_POST['Password'];
    $RoleID= $_POST['RoleID'];
    $email= $_POST['Email'];
    
    $filename="UsersFile.txt";
    
    addUser($email,$password,$RoleID,$name,$filename);

    
}
?>