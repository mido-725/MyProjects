<?php
    include_once "PatientFnc.php";
    include_once "DeleteForm_patients.html";
    
    //$fileName="team.txt";
    
    $name;
    $filename;
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $name= $_POST['name'];
        $filename= "patients_list.txt";
        echo $name;
        
        Deletepatients($name,$filename);
    
        
    }
?>