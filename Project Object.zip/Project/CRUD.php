<?php
include_once "Userfnc.php";
include_once "data.html";

//$fileName="team.txt";

if($_SERVER["REQUEST_METHOD"] == "POST") {
    

    // collect value of input field
    $name = $_POST['Name'];
    $id= $_POST['ID'];
    $password= $_POST['Password'];
    $RoleID= $_POST['RoleID'];
    $email= $_POST['Email'];
    
    
    $filename="UsersFile.txt";
    UpdateUser($id, $email,$password,$RoleID,$name,$filename);

    
}
?>