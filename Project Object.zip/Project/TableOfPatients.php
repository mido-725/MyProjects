<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>table Of Patients</title>
</head>
<body>
    <h1>List of Patients</h1>
    <table border= 5>
        <tr> 
            <td>Name</td>
            <td>phone</td>
            <td>National_ID</td>
            <td>Disease</td>
        </tr>



<?php


    include_once "functins.php";
    $filename="patients_list.txt";
    $arr=ListAll($filename);
    

    
    for($i=0;$i<count($arr);$i++)
    {
        
        $arrayline= explode("~",$arr[$i]);
        if(isset($arrayline[0])){
        $result[0]=$arrayline[0];
        echo "<tr><td>" .$arrayline[0]."</td>" ;
        }
        if(isset($arrayline[1])){
            $result[1]=$arrayline[1];
            echo "<td>" .$arrayline[1]."</td>" ;
            }
            if(isset($arrayline[2])){
                $result[2]=$arrayline[2];
                echo "<td>" .$arrayline[2]."</td>" ;
                }
                if(isset($arrayline[3])){
                    $result[3]=$arrayline[3];
                    echo "<td>" .$arrayline[3]."</td></tr>" ;
                    }
        
    }    
    
?>
    
    </table>
</body>
</html>
