<?php
    include_once "Userfnc.php";
    include_once "ReadForm_medicineinfo.html";
    include_once "Functins.php";
    
    //$fileName="team.txt";
    
    $name;
    $filename;
    
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $name= $_POST['name'];
        $filename="medicinelist.txt";
        $arrayresult= getmedicineByname($name,$filename);
        echo "medicine Information :" .$arrayresult[0] . " ~ " . $arrayresult[1] . " ~ " . $arrayresult[2]  ;
        
    }
?>