<?php
    class personal_information
    {
        private $name;
        private $phone_number;
        private $national_id;
        private $address;
        private $age;
        private $gender;
	function getName() {
		return $this->name;
	}
	function setName($name): self {
		$this->name = $name;
		return $this;
	}
	function getPhone_number() {
		return $this->phone_number;
	}
	function setPhone_number($phone_number): self {
		$this->phone_number = $phone_number;
		return $this;
	}
	function getNational_id() {
		return $this->national_id;
	}
	function setNational_id($national_id): self {
		$this->national_id = $national_id;
		return $this;
	}
	function getAddress() {
		return $this->address;
	}
	function setAddress($address): self {
		$this->address = $address;
		return $this;
	}
	function getAge() {
		return $this->age;
	}
	function setAge($age): self {
		$this->age = $age;
		return $this;
	}
	function getGender() {
		return $this->gender;
	}
	function setGender($gender): self {
		$this->gender = $gender;
		return $this;
	}
}
?>