<?php
include_once "Userfnc.php";
include_once "CreateAppointment.html";
include_once "Functins.php";




if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $Name = $_POST['Name'];
    $Specialty= $_POST['Specialty'];
    $Time= $_POST['Time'];
    $Date= $_POST['Date'];
    
    $fileName="ListofAppointment.txt";
    addAppointment($Name,$Specialty,$Time,$Date,$fileName);

    
}
?>