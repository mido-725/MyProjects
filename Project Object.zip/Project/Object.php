<?php   


class UserType
{
    public $UserName;
    public $ID;

    function DisplayUserName($UserName)
    {
        echo $UserName;
    }
}

$ObjUser=new UserType();
$ObjUser->UserName="Khaled";
$ObjUser->ID=213877;
$arrayObj=array();
$arrayObj[0]=$ObjUser;
$ObjUser=new UserType();
$ObjUser->UserName="Hany";
$ObjUser->ID=212187;
$arrayObj[1]=$ObjUser;

for($i=0;$i<count($arrayObj);$i++)
{
    
    echo $arrayObj[$i]->UserName. " ~ "  ;
}
?>


