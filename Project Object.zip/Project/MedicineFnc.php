<?php
include_once "Functins.php";
//add
    function addmedicine($name, $quntity, $expiration_date,$fileName)
    {
        $record = $name . "~" . $quntity . "~" . $expiration_date  ;
        //echo $record;
        if (searchmedicine($fileName,$name, $expiration_date) == false) {
            StoreRecord($fileName, $record);
            return true;
        } else {
            header("location:updateform_medicine.html");
            return false;
        }
    
    }
//Read
function getmedicineByname($name,$fileName)
{
    
    $Record = getRowByname($fileName, "~", $name);

    $ArrayResult = explode("~", $Record);
    $Result[0] = $ArrayResult[0];
    $Result[1] = $ArrayResult[1];
    $Result[2] = $ArrayResult[2];
    return $Result;
}
//update
function Updatemedicine($name, $quantity, $expiration_date, $fileName)
{
    $record = $name . "~" . $quantity . "~" . $expiration_date  . "\r\n";
    $r = getRowByname($fileName, "~", $name);
    //echo $record ."NEW <br>";
    //echo $r ."NEW <br>";
    UpdateRecord($fileName, $record, $r);
}
//delete
function Deletemedicine($name,$fileName)
{
    
    $r = getRowByname($fileName, "~", $name);
    //echo $r;
    //exit();
    DeleteRecord($fileName, $r);
}
?>