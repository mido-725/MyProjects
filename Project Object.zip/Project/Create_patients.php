<?php
    include_once "patientFnc.php";
    include_once "CreateForm_patients.html";
    
    //$fileName="team.txt";
    
    $name;
    $phone;
    $national_id;
    $disease;
    $filename;
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $name = $_POST['Name'];
        $phone= $_POST['phone'];
        $national_id= $_POST['national_ID'];
        $disease= $_POST['disease'];
        $filename= "patients_list.txt";
        
        /*echo $name;
        echo '~';
        echo $phone;
        echo '~';
        echo $national_id;
        echo '~';
        echo $disease;*/
        addpatients($name,$phone,$national_id,$disease,$filename);
    
        
    }
?>