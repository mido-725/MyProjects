<?php
include_once "Functins.php";
//Create
function addpatients($name,$phone,$national_id,$disease, $fileName)
{
    
    $record= $name. "~" . $phone . "~" . $national_id . "~" . $disease ;
    
    if (search($fileName, $national_id) == false) {
    StoreRecord($fileName, $record);   
        return true;
    } else {
        return false;
    }
}
//Read
function getpatientByname($name,$fileName)
{
    
    $Record = getRowByname($fileName, "~", $name);

    $ArrayResult = explode("~", $Record);
    $Result[0] = $ArrayResult[0];
    $Result[1] = $ArrayResult[1];
    $Result[2] = $ArrayResult[2];
    $Result[3] = $ArrayResult[3];
    return $Result;
}
//Update
function Updatepatient($name, $phone, $national_id, $disease,$fileName)
{
    $record = $name . "~" . $phone . "~" . $national_id . "~" . $disease  . "\r\n";
    $r = getRowByname($fileName, "~", $name);
    //echo $record ."NEW <br>";
    //echo $r ."NEW <br>";
    UpdateRecord($fileName, $record, $r);

}
//Delete
function Deletepatients($name,$fileName)
{
    
    $r = getRowByname($fileName, "~", $name);
    //echo $r;
    //exit();
    DeleteRecord($fileName, $r);
}
?>