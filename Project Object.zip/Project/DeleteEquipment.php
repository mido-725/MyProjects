<?php
include_once "Userfnc.php";
include_once "DeleteEquipment.html";


if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $id= $_POST['ID'];
    
    
    $filename="ListofEquipment.txt";
    DeleteUser($id,$filename);

    
}
?>