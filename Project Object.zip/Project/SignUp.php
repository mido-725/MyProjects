<?php
include_once "Userfnc.php";
include_once "Functins.php";
include_once "signUp.html";

$ct=0;
$name=null;
$email=null;
$password=null;
if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $name = $_POST['Name'];
    $password= $_POST['Password'];
    $RoleID= $_POST['RoleID'];
    $email= $_POST['Email'];
    
        $filename="UsersFile.txt";
    
        
        
            $password=Encrypt($password,3);
            if(addUser($email,$password,$RoleID,$name,$filename)==false)
            {
                echo '<b>this user is already exist</b>';
            }
            else
            {
                header("location:login.php");
            }
        
        

        
    
}
?>