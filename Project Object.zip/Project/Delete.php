<?php
include_once "Userfnc.php";
include_once "DeleteForm.html";

//$fileName="team.txt";



if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // collect value of input field
    $id= $_POST['ID'];
    
    
    $filename="UsersFile.txt";
    
    DeleteUser($id,$filename);

    
}
?>