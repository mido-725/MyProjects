<?php
include_once "Functins.php";
//$fileName = "team.txt";


// CREATE
function addspeciality($name,$fileName)
{
    $id = getLastId($fileName, "~") + 1;
    $record = $id . "~" . $name;
	//echo $record;
    if (searchUser($fileName, $name) == false) {
        StoreRecord($fileName, $record);
        return true;
    } else {
        return false;
    }

}


// Read
function getspecialtyByid($id,$fileName)
{
    
    $Record = getRowById($fileName, "~", $id);

    $ArrayResult = explode("~", $Record);
    if(isset($ArrayResult[0]))
    {
    $Result[0] = $ArrayResult[0];
    }
    if(isset($ArrayResult[1]))
    {
    $Result[1] = $ArrayResult[1];
    }
    return $Result;
}


function getAllspecialty($fileName)
{
    
    $R = ListAll($fileName);
    return $R;
}

function getAllUsersByKeyWord($KeyWord,$fileName)
{
    
    $R = SearhKeyword($fileName, $KeyWord);
    //echo $R[0] ."Ayman";
    return $R;
}



// Update
function UpdateUser($oid,$id, $name,$fileName)
{
    $record = $id . "~" . $name. "\r\n";
    $r = getRowById($fileName, "~", $oid);
    //echo $record ."NEW <br>";
    //echo $r ."NEW <br>";
    UpdateRecord($fileName, $record, $r);

}


// Delete
function Deletespecialty($id,$fileName)
{
    
    $r = getRowById($fileName, "~", $id);
    
    //echo $r;
    //exit();
    DeleteRecord($fileName, $r);
}





?>