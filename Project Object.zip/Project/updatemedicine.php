<?php
    include_once "Userfnc.php";
    include_once "updateform_medicine.html";
    
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // collect value of input field
        $name = $_POST['Name'];
        $quantity= $_POST['quantity'];
        $expiration_date= $_POST['expiration_date'];
        $filename=  "medicinelist.txt";
        Updatemedicine($name, $quantity,$expiration_date,$filename);
    
        
    }
?>