const express = require("express");
const path = require("path");
const app = express();
const hbs = require("hbs");
const collection = require("./mongodb");

const tempelatePath = path.join(__dirname, '../tempelates');
app.use(express.json());
app.set("view engine", "hbs");
app.set("views", tempelatePath);


app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
    res.render("login");
});

app.get("/signup", (req, res) => {
    res.render("signup");
});
app.get("/update", (req, res) => {
    res.render("update");
});

app.post("/signup", async (req, res) => {
    const data = {
        name: req.body.name,
        password: req.body.password,
    };

    try {
        const checking = await collection.findOne({ name: req.body.name });
        if (checking) {
          
            res.send("<script>alert('User details already exist'); window.location.href='/signup';</script>");
        } else {
            await collection.insertMany([data]);
            res.render("home");
        }
    } catch (error) {
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
});

app.post("/update", async (req, res) => {
    const data = {
        name: req.body.name,
        password: req.body.password,
    };

    try {
        const existingUser = await collection.findOne({ name: req.body.name });
        if (existingUser) {
          
            await collection.updateOne({ name: req.body.name }, { $set: { password: req.body.password } });
           
            res.send("<script>alert('Update successful'); window.location.href='/';</script>");
        } else {
            res.send("<script>alert('check the correct username'); window.location.href='/';</script>");
        }
    } catch (error) {
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
});


app.post("/login", async (req, res) => {

    try {
        const check = await collection.findOne({ name: req.body.name })

        if (check.password === req.body.password) {
            res.status(201).render("home", { naming: `${req.body.password}+${req.body.name}` });
        } else {
            
            res.send("<script>alert('Incorrect password'); window.location.href='/';</script>");
        }

    } catch (e) {
        
        res.send("<script>alert('Wrong details'); window.location.href='/';</script>");
    }
});

app.listen(3000, () => {
    console.log("port connected");
});
