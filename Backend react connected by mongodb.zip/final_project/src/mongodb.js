const mongoose=require("mongoose")

mongoose.connect("mongodb+srv://youssefseada193:sljcGhDZF26tSeXn@cluster0.fk437fo.mongodb.net/login")
.then(()=>{
    console.log("mongoose connected");
})
.catch((e)=>{
    console.log("failed");
})

const logInSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    }
})

const collection = mongoose.model("collection1",logInSchema)

module.exports=collection