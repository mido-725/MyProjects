﻿using Project.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace Project
{
    public partial class Form1 : Form
    {
        Appdbcontext db = new Appdbcontext();
        public Form1()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            Clinc clinc1 = new Clinc()
            {
                Price = int.Parse(txtprice.Text),
                count = int.Parse(txtcount.Text),
                Name = txtname.Text,
                
            };

            db.clincs.Add(clinc1);
            db.SaveChanges();
            var clinc = db.clincs.ToList();
            dataGridView1.DataSource = clinc;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var clinc = db.clincs.ToList();
            dataGridView1.DataSource = clinc;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 cs = new Form2();
            this.Hide();
            cs.ShowDialog();
            this.Close();
        }
    }
}
