﻿using Project.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class Appdbcontext : DbContext
    {
        public Appdbcontext() : base("Data source=SEADA\\SQLEXPRESS;Database=Project Clinc ;integrated security=true\r\n")
        {
                
        }
        public DbSet<Clinc> clincs { get; set; }
    }
}
