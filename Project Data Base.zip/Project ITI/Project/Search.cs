﻿using Project.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Search : Form
    {
        Appdbcontext db = new Appdbcontext();
        public Search()
        {
            InitializeComponent();
        }

        private void Search_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int w = int.Parse(textBox1.Text);
            var clinc = db.clincs.Where(p => p.Id == w).ToList();
            dataGridView1.DataSource = clinc;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 cs = new Form2();
            this.Hide();
            cs.ShowDialog();
            this.Close();
        }
    }
}
