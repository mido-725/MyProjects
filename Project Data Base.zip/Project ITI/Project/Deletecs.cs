﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Deletecs : Form
    {
        Appdbcontext db = new Appdbcontext();
        public Deletecs()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int w = int.Parse(textBox1.Text);
            var clinc = db.clincs.Where(p => p.Id == w).ToList();
            var clincc = db.clincs.Find(w);
            db.clincs.Remove(clincc);
            db.SaveChanges();
            MessageBox.Show("delete successfully");
            var cclinc = db.clincs.ToList();
            dataGridView1.DataSource = cclinc;
        }

        private void Deletecs_Load(object sender, EventArgs e)
        {
            var clinc = db.clincs.ToList();
            dataGridView1.DataSource = clinc;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 cs = new Form2();
            this.Hide();
            cs.ShowDialog();
            this.Close();
        }
    }
}
