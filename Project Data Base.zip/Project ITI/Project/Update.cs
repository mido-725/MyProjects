﻿using Project.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Migrations;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Project
{
    public partial class Update : Form
    {
        Appdbcontext db = new Appdbcontext();
        Clinc cc = null;
        public Update()
        {
            InitializeComponent();
        }

        private void Update_Load(object sender, EventArgs e)
        {
            var c = db.clincs.ToList();
            dataGridView1.DataSource = c;
        }

        private void Save_Click(object sender, EventArgs e)
        {
            cc.Name = txtname.Text;
            cc.Price = int.Parse(txtprice.Text);
            cc.count = int.Parse(txtcount.Text);
            db.clincs.AddOrUpdate(cc);
            db.SaveChanges();
            MessageBox.Show("updated successfully");
            var c = db.clincs.ToList();
            dataGridView1.DataSource = c;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = int.Parse(txtID.Text);
            cc = db.clincs.Where(d => d.Id == x).FirstOrDefault();
            txtname.Text = cc.Name;
            txtprice.Text = cc.Price.ToString();
            txtcount.Text = cc.count.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 cs = new Form2();
            this.Hide();
            cs.ShowDialog();
            this.Close();
        }
    }
}
